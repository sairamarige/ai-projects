"""CLI demo of the v4 async Supervisor (no HTTP server needed).

Run:
    python run_demo.py
"""
from __future__ import annotations

import asyncio
import logging

from app.bootstrap import build_default_supervisor

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


async def main() -> None:
    supervisor = await build_default_supervisor()

    sample_queries = [
        "Hello there!",
        "What's the weather in Hyderabad?",
        "What about tomorrow?",              # memory follow-up
        "Calculate 12 * (3 + 4)",
        "What's the weather in Tokyo and calculate 45 + 90",  # parallel multi-intent
        "Give me Python code to reverse a string",
        "Translate hello to Spanish",         # dynamically loaded plugin
    ]

    print("=== Supervisor Agent Demo (v4, async) ===\n")
    for query in sample_queries:
        decision = await supervisor.route(query, session_id="demo")
        print(f"Query:        {query}")
        print(f"Routed to:    {decision.agent_names}")
        print(f"Response:     {decision.response}")
        print("-" * 60)

    print("\nMetrics:", supervisor.metrics_summary())

    print("\n=== Streaming demo ===")
    async for chunk in supervisor.route_stream("What's the weather in Delhi?", session_id="demo"):
        print(chunk, end="", flush=True)
    print()

    if supervisor.session_store is not None:
        await supervisor.session_store.close()


if __name__ == "__main__":
    asyncio.run(main())
