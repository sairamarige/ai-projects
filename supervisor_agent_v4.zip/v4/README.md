# Supervisor Agent System — v4 (Production-Grade Rewrite)

v4 turns the v3 single-file prototype into a real service: async agents,
a FastAPI HTTP layer with streaming, SQLite-backed session persistence,
TF-IDF routing, and Docker packaging.

## What changed from v3

| Area | v3 | v4 |
|---|---|---|
| Agent interface | Synchronous `can_handle`/`handle` | Async; independent clauses run via `asyncio.gather` instead of a `ThreadPoolExecutor` |
| Routing | Jaccard similarity over token sets | TF-IDF + cosine similarity, IDF shared across every agent's example phrases |
| State | One in-process `AgentState`, lost on restart | Per-`session_id` state persisted to SQLite (`SessionStore`); survives restarts and works across multiple API workers sharing one DB file |
| Interface | CLI demo only | FastAPI service: `/chat`, `/chat/stream` (SSE), `/sessions/{id}/history`, `/metrics`, `/health` |
| Reliability | Bounded retries + fallback | Retries **and** a per-call timeout (`asyncio.wait_for`), then fallback |
| Deployment | N/A | `Dockerfile` + `docker-compose.yml` |
| Tests | 15 sync tests | 24 async tests (routing, memory, concurrency timing, retries/timeouts, plugins, metrics under load, streaming, persistence across instances) |

## A bug found (and fixed) building this

Testing multi-intent follow-ups turned up a real bug: after
`"weather in Mumbai and calculate 7*8"`, asking `"what about tomorrow?"`
incorrectly routed to `CalculatorAgent` — whichever clause's agent ran
*last* silently overwrote `context["last_agent"]`, so the follow-up lost
track of which clause it actually referred to.

**Fix:** the Supervisor now stores every distinct agent used in a turn
(`context["last_agents"]`), and a low-confidence follow-up is re-scored
against each of those candidates, picking whichever one actually fits —
not just whichever ran last. See
`test_multi_intent_followup_targets_correct_agent_not_last_clause` in
`tests/test_supervisor.py` for the regression test.

## Project layout

```
app/
  config.py        # SupervisorConfig: config.json + env var overrides
  state.py          # AgentState (per-session context/history)
  scoring.py         # TF-IDF corpus + cosine-similarity scorer
  aggregator.py       # Multi-clause response aggregation
  metrics.py           # Query count, latency, per-agent usage, failure rate
  persistence.py        # SQLite SessionStore (aiosqlite)
  supervisor.py          # Async routing core: parallel exec, retries, streaming
  plugin_loader.py         # Dynamic plugin discovery
  bootstrap.py               # Wires up the default agent set + shared TF-IDF corpus
  api.py                      # FastAPI app
  agents/
    base.py                   # BaseAgent (async interface) + AgentType enum
    weather.py, calculator.py, python_agent.py, chat.py
  plugins/
    translation_agent.py       # Example dynamically-loaded plugin
tests/
  test_supervisor.py            # Core routing/memory/parallel/retry/plugin/metrics tests
  test_api.py                    # FastAPI endpoint tests (httpx ASGI transport)
run_demo.py                       # CLI demo, no HTTP server needed
config.json, requirements.txt, requirements-dev.txt, pytest.ini
Dockerfile, docker-compose.yml
```

## Running it

### CLI demo
```bash
pip install -r requirements.txt
python run_demo.py
```

### HTTP service
```bash
pip install -r requirements.txt
uvicorn app.api:app --reload
```

```bash
curl -X POST localhost:8000/chat \
  -H 'Content-Type: application/json' \
  -d '{"query": "weather in Hyderabad and calculate 12*7", "session_id": "alice"}'

curl -X POST localhost:8000/chat/stream \
  -H 'Content-Type: application/json' \
  -d '{"query": "what about tomorrow?", "session_id": "alice"}'

curl localhost:8000/sessions/alice/history
curl localhost:8000/metrics
```

### Docker
```bash
docker compose up --build
```
Mounts a named volume (`supervisor_data`) at `/data` so `supervisor.db`
(and therefore all session memory) survives container restarts.

> Docker itself wasn't available in the sandbox this was built in, so the
> image hasn't been build-tested end-to-end. What *was* verified: the
> FastAPI app boots and serves correctly from the exact minimal file set
> the Dockerfile copies (`app/`, `config.json`, `requirements.txt`) run
> from a clean directory with `WORKDIR`-equivalent relative paths — the
> same layout the container uses. Worth a real `docker compose up
> --build` before deploying.

### Tests
```bash
pip install -r requirements-dev.txt
pytest -v
```
24 tests, all passing, including a genuine concurrency check (two
0.2s-each clauses complete in ~0.2s total, not ~0.4s) and a check that
metrics don't get corrupted under 20 concurrent requests.

## Configuration

`config.json`, overridable via env vars (`SUPERVISOR_MIN_CONFIDENCE`,
`SUPERVISOR_MULTI_THRESHOLD`, `SUPERVISOR_MAX_RETRIES`,
`SUPERVISOR_PARALLEL`, `SUPERVISOR_PLUGINS_DIR`, `SUPERVISOR_DB_PATH`,
`SUPERVISOR_REQUEST_TIMEOUT_S`, `SUPERVISOR_STREAM_CHUNK_SIZE`).

## Adding an agent

Drop a `.py` file in `app/plugins/` with a class implementing `BaseAgent`
(async `can_handle`/`handle`, an `agent_type`) — it's picked up
automatically at startup, no changes to the Supervisor needed. See
`app/plugins/translation_agent.py`.

## Scoped out (same reasoning as v3)

- **Real sentence embeddings** — would need model weights this
  environment can't download; TF-IDF is the offline-friendly upgrade
  path instead.
- **LangGraph migration** — a genuine framework switch, not a patch on
  this codebase.
- **Multi-worker production deployment (Redis/Postgres instead of
  SQLite)** — SQLite is fine for one process or a few workers on shared
  disk; a true horizontally-scaled deployment would want a networked
  store instead, which is a bigger infrastructure decision than this
  rewrite's scope.
