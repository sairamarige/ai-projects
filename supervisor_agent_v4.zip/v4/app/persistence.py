"""SQLite-backed persistence for per-session conversation state.

Replaces v3's single in-process `AgentState` (lost on restart, and unusable
across multiple worker processes) with a store keyed by `session_id`, so a
FastAPI deployment with several workers — or a restart — doesn't lose
conversation memory.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

import aiosqlite

from app.state import AgentState

logger = logging.getLogger("supervisor.persistence")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    context_json TEXT NOT NULL,
    history_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


class SessionStore:
    """Thin async wrapper around a SQLite database of session state."""

    def __init__(self, db_path: str | Path):
        self._db_path = str(db_path)
        self._db: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        self._db = await aiosqlite.connect(self._db_path)
        await self._db.execute(_SCHEMA)
        await self._db.commit()
        logger.info("Connected to session store at %s", self._db_path)

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None

    async def load(self, session_id: str) -> AgentState:
        assert self._db is not None, "SessionStore not connected"
        cursor = await self._db.execute(
            "SELECT context_json, history_json FROM sessions WHERE session_id = ?",
            (session_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            return AgentState(session_id=session_id)
        context_json, history_json = row
        return AgentState(
            session_id=session_id,
            context=json.loads(context_json),
            history=json.loads(history_json),
        )

    async def save(self, state: AgentState) -> None:
        assert self._db is not None, "SessionStore not connected"
        await self._db.execute(
            """
            INSERT INTO sessions (session_id, context_json, history_json, updated_at)
            VALUES (?, ?, ?, datetime('now'))
            ON CONFLICT(session_id) DO UPDATE SET
                context_json = excluded.context_json,
                history_json = excluded.history_json,
                updated_at = excluded.updated_at
            """,
            (state.session_id, json.dumps(state.context), json.dumps(state.history)),
        )
        await self._db.commit()

    async def delete(self, session_id: str) -> None:
        assert self._db is not None, "SessionStore not connected"
        await self._db.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        await self._db.commit()

    async def list_sessions(self) -> list[str]:
        assert self._db is not None, "SessionStore not connected"
        cursor = await self._db.execute("SELECT session_id FROM sessions ORDER BY updated_at DESC")
        rows = await cursor.fetchall()
        return [r[0] for r in rows]
