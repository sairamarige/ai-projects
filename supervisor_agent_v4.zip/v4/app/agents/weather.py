from __future__ import annotations

import asyncio
import logging
import re

from app.agents.base import AgentType, BaseAgent
from app.scoring import TfidfCorpus, TfidfScorer
from app.state import AgentState

logger = logging.getLogger("supervisor.agents.weather")


class WeatherAgent(BaseAgent):
    agent_type = AgentType.WEATHER
    example_phrases = (
        "what is the weather in London",
        "weather forecast for tomorrow",
        "is it raining today",
        "temperature outside right now",
        "how humid is it in Tokyo",
    )

    _MOCK_DB = {
        "hyderabad": "31°C, partly cloudy, light breeze",
        "new york": "22°C, clear skies",
        "london": "17°C, overcast with light rain",
        "tokyo": "27°C, humid, scattered showers",
        "delhi": "34°C, hazy sunshine",
    }
    _KEYWORDS = ("weather", "forecast", "temperature", "rain", "sunny", "humid")
    _FOLLOWUP_WORDS = ("tomorrow", "today", "now", "there", "again", "what about", "and there")
    _TRAILING_WORDS = ("right now", "today", "now", "tomorrow", "currently", "please")
    _STOPWORDS = {
        "what", "whats", "what's", "s", "the", "is", "how", "hows", "how's",
        "today", "current", "todays", "today's", "like", "outside",
    }

    def __init__(self, corpus: TfidfCorpus) -> None:
        self._scorer = TfidfScorer(self.example_phrases, corpus)

    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        q = query.lower()
        if any(kw in q for kw in self._KEYWORDS):
            return 0.95
        return round(0.6 * self._scorer.score(query), 2)

    async def handle(self, query: str, state: AgentState) -> str:
        # Simulated network I/O for a real weather API call.
        await asyncio.sleep(0.05)

        city = self._extract_city(query)
        if not city and state.context.get("last_city") and self._looks_like_followup(query):
            city = state.context["last_city"]
            logger.info("WeatherAgent: resolved follow-up to last_city=%r", city)

        if not city:
            return "I can check the weather for you — which city did you mean?"

        state.context["last_city"] = city
        return f"Weather in {city.title()}: {self.get_weather(city)}"

    def get_weather(self, city: str) -> str:
        return self._MOCK_DB.get(
            city.strip().lower(),
            "26°C, mild conditions (simulated default — city not in local data)",
        )

    def _looks_like_followup(self, query: str) -> bool:
        q = query.lower()
        return any(w in q for w in self._FOLLOWUP_WORDS) or len(q.split()) <= 4

    def _extract_city(self, query: str) -> str | None:
        match = re.search(r"weather\s+(?:in|for|at)\s+([a-zA-Z\s]+)", query, re.IGNORECASE)
        if match:
            return self._clean_city(match.group(1)) or None
        match = re.search(r"([a-zA-Z\s]+)\s+weather", query, re.IGNORECASE)
        if match:
            return self._clean_city(match.group(1)) or None
        return None

    def _clean_city(self, raw: str) -> str:
        city = raw.strip().rstrip("?.!")
        changed = True
        while changed:
            changed = False
            for word in self._TRAILING_WORDS:
                new_city = re.sub(rf"\s+{re.escape(word)}\s*$", "", city, flags=re.IGNORECASE)
                if new_city != city:
                    city, changed = new_city, True
        words = [w for w in re.split(r"\s+", city.strip()) if w]
        meaningful = [w for w in words if w.lower() not in self._STOPWORDS]
        return " ".join(meaningful)
