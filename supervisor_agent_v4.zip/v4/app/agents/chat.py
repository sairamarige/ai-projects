from __future__ import annotations

import asyncio

from app.agents.base import AgentType, BaseAgent
from app.state import AgentState


class GeneralChatAgent(BaseAgent):
    agent_type = AgentType.CHAT

    _GREETINGS = ("hi", "hello", "hey", "good morning", "good evening", "good afternoon")
    _THANKS = ("thanks", "thank you", "appreciate it")
    _FAREWELLS = ("bye", "goodbye", "see you", "later")

    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        q = query.lower().strip()
        if (
            any(q.startswith(g) for g in self._GREETINGS)
            or any(t in q for t in self._THANKS)
            or any(f in q for f in self._FAREWELLS)
        ):
            return 0.8
        return 0.2  # baseline fallback score

    async def handle(self, query: str, state: AgentState) -> str:
        await asyncio.sleep(0)
        q = query.lower().strip()
        if any(q.startswith(g) for g in self._GREETINGS):
            return "Hello! How can I help you today?"
        if any(t in q for t in self._THANKS):
            return "You're welcome! Anything else I can help with?"
        if any(f in q for f in self._FAREWELLS):
            return "Goodbye! Have a great day."
        return "I'm here to chat! Ask me about weather, math, or Python code too."

    def apology(self, reason: str) -> str:
        """Used by the Supervisor's fallback path when an agent fails."""
        return f"Sorry, I ran into a problem handling that ({reason}). Could you try rephrasing?"
