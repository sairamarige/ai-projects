from __future__ import annotations

import ast
import asyncio
import operator
import re

from app.agents.base import AgentType, BaseAgent
from app.scoring import TfidfCorpus, TfidfScorer
from app.state import AgentState


class CalculatorAgent(BaseAgent):
    agent_type = AgentType.CALCULATOR
    example_phrases = (
        "calculate twelve times four",
        "what is 45 divided by 9",
        "add five and ten",
        "solve this math expression",
    )

    _OPS = {
        ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.USub: operator.neg, ast.UAdd: operator.pos,
    }
    _WORD_OPS = {
        "plus": "+", "add": "+", "added to": "+", "sum of": "+",
        "minus": "-", "subtract": "-", "less": "-",
        "times": "*", "multiply": "*", "multiplied by": "*",
        "divide": "/", "divided by": "/", "over": "/",
    }

    def __init__(self, corpus: TfidfCorpus) -> None:
        self._scorer = TfidfScorer(self.example_phrases, corpus)

    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        return 0.9 if self._extract_expression(query) else round(0.5 * self._scorer.score(query), 2)

    async def handle(self, query: str, state: AgentState) -> str:
        await asyncio.sleep(0)  # keep the interface uniformly async
        expr = self._extract_expression(query)
        if not expr:
            return "I didn't find a valid arithmetic expression to calculate."
        try:
            result = self._safe_eval(expr)
        except ZeroDivisionError:
            return f"'{expr}' involves division by zero — can't compute that."
        except (SyntaxError, ValueError):
            return f"I couldn't safely evaluate '{expr}'. Try something like '12 * (3 + 4)'."
        return f"{expr} = {result}"

    def _extract_expression(self, query: str) -> str | None:
        match = re.search(r"[-+]?[\d(][\d\s()+\-*/.%^]*[\d)]", query)
        if match:
            expr = match.group(0).strip()
            if re.search(r"[+\-*/%^]", expr):
                return expr.replace("^", "**")

        q = query.lower()
        numbers = re.findall(r"-?\d+\.?\d*", q)
        if len(numbers) >= 2:
            for word, symbol in self._WORD_OPS.items():
                if word in q:
                    return f"{numbers[0]} {symbol} {numbers[1]}"
        return None

    def _safe_eval(self, expr: str) -> float:
        node = ast.parse(expr, mode="eval").body
        return self._eval_node(node)

    def _eval_node(self, node: ast.AST) -> float:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float)):
                return node.value
            raise ValueError("Unsupported constant")
        if isinstance(node, ast.BinOp) and type(node.op) in self._OPS:
            return self._OPS[type(node.op)](self._eval_node(node.left), self._eval_node(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in self._OPS:
            return self._OPS[type(node.op)](self._eval_node(node.operand))
        raise ValueError("Unsupported expression")
