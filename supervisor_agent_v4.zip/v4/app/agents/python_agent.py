from __future__ import annotations

import asyncio

from app.agents.base import AgentType, BaseAgent
from app.scoring import TfidfCorpus, TfidfScorer
from app.state import AgentState


class PythonAgent(BaseAgent):
    agent_type = AgentType.PYTHON
    example_phrases = (
        "write python code to reverse a string",
        "give me a function for fibonacci",
        "show me a script that sorts a list",
        "python snippet for factorial",
    )

    _KEYWORDS = (
        "python", "code", "function", "script", "snippet",
        "reverse", "fibonacci", "factorial", "sort", "prime",
        "palindrome", "swap",
    )
    _SNIPPETS = {
        "reverse a string": "def reverse_string(s):\n    return s[::-1]",
        "reverse string": "def reverse_string(s):\n    return s[::-1]",
        "fibonacci": (
            "def fibonacci(n):\n"
            "    a, b = 0, 1\n"
            "    for _ in range(n):\n"
            "        a, b = b, a + b\n"
            "    return a"
        ),
        "factorial": "def factorial(n):\n    return 1 if n <= 1 else n * factorial(n - 1)",
        "sort a list": "sorted_list = sorted(my_list)",
        "sort list": "sorted_list = sorted(my_list)",
        "prime": (
            "def is_prime(n):\n"
            "    if n < 2:\n"
            "        return False\n"
            "    for i in range(2, int(n ** 0.5) + 1):\n"
            "        if n % i == 0:\n"
            "            return False\n"
            "    return True"
        ),
        "read a file": "with open('file.txt', 'r') as f:\n    content = f.read()",
        "read file": "with open('file.txt', 'r') as f:\n    content = f.read()",
        "swap two variables": "a, b = b, a",
        "swap variables": "a, b = b, a",
        "palindrome": "def is_palindrome(s):\n    return s == s[::-1]",
    }

    def __init__(self, corpus: TfidfCorpus) -> None:
        self._scorer = TfidfScorer(self.example_phrases, corpus)

    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        q = query.lower()
        if any(k in q for k in self._KEYWORDS):
            return 0.85
        return round(0.5 * self._scorer.score(query), 2)

    async def handle(self, query: str, state: AgentState) -> str:
        await asyncio.sleep(0)
        q = query.lower()
        for key, snippet in self._SNIPPETS.items():
            if key in q:
                return f"```python\n{snippet}\n```"
        return "```python\n# Generic snippet — customize as needed\nprint('Hello, World!')\n```"
