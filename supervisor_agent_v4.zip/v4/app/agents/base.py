"""Async base interface all agents implement."""
from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import AsyncIterator, ClassVar

from app.state import AgentState


class AgentType(str, Enum):
    WEATHER = "WeatherAgent"
    CALCULATOR = "CalculatorAgent"
    PYTHON = "PythonAgent"
    CHAT = "GeneralChatAgent"
    TRANSLATION = "TranslationAgent"  # example plugin, loaded dynamically


class BaseAgent(ABC):
    """Common interface all agents implement. The Supervisor only ever talks
    to this interface — adding a new agent never requires modifying the
    Supervisor (Open/Closed Principle), whether it's registered manually or
    discovered dynamically from the plugins directory.

    All agent methods are async so the Supervisor can run many agents
    concurrently with `asyncio.gather` instead of a thread pool, and so an
    agent backed by a real network call (an LLM, a weather API, ...) is a
    drop-in replacement for the mocked ones here.
    """

    agent_type: ClassVar[AgentType]
    example_phrases: ClassVar[tuple[str, ...]] = ()

    @abstractmethod
    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        """Confidence in [0.0, 1.0] that this agent can handle `query`."""
        raise NotImplementedError

    @abstractmethod
    async def handle(self, query: str, state: AgentState) -> str:
        """Process the query (optionally reading/writing `state`) and return
        a response string."""
        raise NotImplementedError

    async def stream(self, query: str, state: AgentState) -> AsyncIterator[str]:
        """Default streaming implementation: compute the full response, then
        yield it in fixed-size chunks. Agents with a genuine token-by-token
        source (e.g. an LLM) can override this for real incremental output."""
        response = await self.handle(query, state)
        chunk_size = 24
        for i in range(0, len(response), chunk_size):
            yield response[i : i + chunk_size]
