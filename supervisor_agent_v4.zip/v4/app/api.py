"""FastAPI service wrapping the Supervisor.

Endpoints:
  POST   /chat                 -> full (non-streaming) response
  POST   /chat/stream           -> Server-Sent-Events streaming response
  GET    /sessions/{id}/history -> this session's conversation history
  DELETE /sessions/{id}         -> forget a session
  GET    /metrics               -> query count, latency, per-agent usage
  GET    /health                -> liveness probe

Run with:  uvicorn app.api:app --reload
"""
from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.bootstrap import build_default_supervisor
from app.config import SupervisorConfig

logger = logging.getLogger("supervisor.api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    config = SupervisorConfig.load()
    app.state.supervisor = await build_default_supervisor(config)
    logger.info("Supervisor service started (db=%s)", config.db_path)
    yield
    if app.state.supervisor.session_store is not None:
        await app.state.supervisor.session_store.close()
    logger.info("Supervisor service stopped")


app = FastAPI(title="Supervisor Agent Service", version="4.0.0", lifespan=lifespan)


class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, description="User's message")
    session_id: str = Field("default", description="Conversation/session identifier")


class ChatResponse(BaseModel):
    session_id: str
    agent_names: list[str]
    response: str
    scores: dict[str, float]


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    decision = await app.state.supervisor.route(req.query, session_id=req.session_id)
    return ChatResponse(
        session_id=req.session_id,
        agent_names=decision.agent_names,
        response=decision.response,
        scores=decision.scores,
    )


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest) -> StreamingResponse:
    async def event_source():
        async for chunk in app.state.supervisor.route_stream(req.query, session_id=req.session_id):
            yield f"data: {json.dumps({'chunk': chunk})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_source(), media_type="text/event-stream")


@app.get("/sessions/{session_id}/history")
async def get_history(session_id: str) -> dict:
    store = app.state.supervisor.session_store
    if store is None:
        raise HTTPException(status_code=501, detail="No session store configured")
    state = await store.load(session_id)
    return {"session_id": session_id, "context": state.context, "history": state.history}


@app.delete("/sessions/{session_id}")
async def delete_session(session_id: str) -> dict:
    store = app.state.supervisor.session_store
    if store is None:
        raise HTTPException(status_code=501, detail="No session store configured")
    await store.delete(session_id)
    return {"session_id": session_id, "deleted": True}


@app.get("/metrics")
async def metrics() -> dict:
    return app.state.supervisor.metrics_summary()


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}
