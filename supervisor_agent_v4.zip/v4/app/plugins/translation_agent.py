"""
Example plugin agent, auto-discovered by `load_plugins()` at Supervisor
startup — nothing in the core app needs to import this file directly.
Drop a new file in `app/plugins/` that subclasses BaseAgent and it's
registered automatically.
"""
from __future__ import annotations

import asyncio
import re

from app.agents.base import AgentType, BaseAgent
from app.state import AgentState


class TranslationAgent(BaseAgent):
    """Tiny toy translator for a handful of common words — enough to prove
    out dynamic plugin loading without needing a real translation API."""

    agent_type = AgentType.TRANSLATION
    example_phrases = (
        "translate hello to Spanish",
        "how do you say goodbye in French",
        "what is thank you in German",
    )

    _DICTIONARY = {
        "spanish": {"hello": "hola", "goodbye": "adios", "thank you": "gracias", "yes": "si", "no": "no"},
        "french": {"hello": "bonjour", "goodbye": "au revoir", "thank you": "merci", "yes": "oui", "no": "non"},
        "german": {"hello": "hallo", "goodbye": "auf wiedersehen", "thank you": "danke", "yes": "ja", "no": "nein"},
    }

    async def can_handle(self, query: str, state: AgentState | None = None) -> float:
        q = query.lower()
        if "translate" in q or "how do you say" in q or re.search(r"\bin (spanish|french|german)\b", q):
            return 0.9
        return 0.0

    async def handle(self, query: str, state: AgentState) -> str:
        await asyncio.sleep(0)
        q = query.lower()
        lang_match = re.search(r"\b(spanish|french|german)\b", q)
        if not lang_match:
            return "Which language would you like that translated into?"
        lang = lang_match.group(1)

        word_match = re.search(r"(?:translate|say)\s+(.+?)\s+(?:to|in)\s+" + lang, q)
        word = word_match.group(1).strip() if word_match else None

        table = self._DICTIONARY[lang]
        if word and word in table:
            return f"'{word}' in {lang.title()} is '{table[word]}'."
        return f"I only know a few words in {lang.title()} — try 'hello', 'goodbye', 'thank you', 'yes', or 'no'."
