"""Lightweight TF-IDF + cosine similarity scorer.

Upgrades the v3 Jaccard-similarity scorer to TF-IDF-weighted cosine
similarity. This is still a classic, dependency-free, offline technique
(no model weights to download), but it's a genuine step up:

- Jaccard treats every token as equally informative, so a query like
  "what is the weather in Paris" scores similarly against *any* example
  bag sharing common words like "what"/"is"/"the".
- TF-IDF down-weights tokens that appear across many agents' example
  phrases (stopword-like, low signal) and up-weights tokens that are
  distinctive to a particular agent's domain (e.g. "weather", "fibonacci",
  "translate"), computed globally across every agent registered with the
  scorer registry so IDF reflects the *actual* corpus in use, not a fixed
  agent's private example list.

Swappable later for real sentence embeddings or an LLM classifier without
changing any agent's `can_handle` call site — `TfidfScorer.score()` keeps
the same interface as the old `SemanticScorer.score()`.
"""
from __future__ import annotations

import math
import re
from collections import Counter


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


class TfidfCorpus:
    """Holds IDF weights computed across *all* agents' example phrases, so
    scoring one agent's relevance benefits from knowing what distinguishes
    it from every other agent in the system."""

    def __init__(self) -> None:
        self._doc_freq: Counter[str] = Counter()
        self._num_docs = 0
        self._idf: dict[str, float] = {}

    def add_documents(self, documents: list[str]) -> None:
        for doc in documents:
            tokens = set(tokenize(doc))
            self._doc_freq.update(tokens)
            self._num_docs += 1
        self._recompute()

    def _recompute(self) -> None:
        # Smoothed IDF: log((1 + N) / (1 + df)) + 1, always positive, avoids
        # division by zero and avoids a term vanishing just because it's in
        # every document.
        n = self._num_docs
        self._idf = {
            term: math.log((1 + n) / (1 + df)) + 1.0
            for term, df in self._doc_freq.items()
        }

    def idf(self, term: str) -> float:
        # Unseen terms get the "maximally distinctive" weight: log(1+N)+1
        return self._idf.get(term, math.log(1 + self._num_docs) + 1.0)


def _tfidf_vector(tokens: list[str], corpus: TfidfCorpus) -> dict[str, float]:
    tf = Counter(tokens)
    return {term: count * corpus.idf(term) for term, count in tf.items()}


def _cosine(a: dict[str, float], b: dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    shared = set(a) & set(b)
    dot = sum(a[t] * b[t] for t in shared)
    norm_a = math.sqrt(sum(v * v for v in a.values()))
    norm_b = math.sqrt(sum(v * v for v in b.values()))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class TfidfScorer:
    """Per-agent scorer: scores a query against this agent's example
    phrases using TF-IDF-weighted cosine similarity, sharing IDF weights
    from a corpus built across every registered agent."""

    def __init__(self, example_phrases: tuple[str, ...], corpus: TfidfCorpus):
        self._corpus = corpus
        self._example_vectors = [
            _tfidf_vector(tokenize(p), corpus) for p in example_phrases
        ]

    def score(self, query: str) -> float:
        if not self._example_vectors:
            return 0.0
        q_vec = _tfidf_vector(tokenize(query), self._corpus)
        return max((_cosine(q_vec, ex) for ex in self._example_vectors), default=0.0)


def build_shared_corpus(*phrase_groups: tuple[str, ...]) -> TfidfCorpus:
    """Build one IDF corpus across every agent's example phrases, so
    scoring reflects what's distinctive *system-wide*, not per-agent."""
    corpus = TfidfCorpus()
    for phrases in phrase_groups:
        corpus.add_documents(list(phrases))
    return corpus
