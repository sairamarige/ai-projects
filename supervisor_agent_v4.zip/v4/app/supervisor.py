"""Async Supervisor — routes queries to the best-fit agent(s).

Upgrades from v3:
  - Agents are async; independent multi-intent clauses run concurrently via
    `asyncio.gather` instead of a `ThreadPoolExecutor` (cheaper, and lets an
    agent do real non-blocking I/O — an HTTP call to a weather API, an LLM
    call, etc.).
  - Per-clause retries use `asyncio.wait_for` for a timeout in addition to
    bounded retry attempts, then fall back to the chat agent with an
    apology.
  - State is per-session and persisted to SQLite (`SessionStore`) rather
    than living only in process memory, so conversation memory survives a
    restart or is shared across multiple API workers hitting the same DB
    file.
  - `route_stream` yields incremental chunks (via each agent's `stream()`)
    for use behind a Server-Sent-Events endpoint.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from typing import AsyncIterator

from app.agents.base import AgentType, BaseAgent
from app.aggregator import ResponseAggregator
from app.config import SupervisorConfig
from app.metrics import SupervisorMetrics
from app.persistence import SessionStore
from app.plugin_loader import load_plugins
from app.state import AgentState

logger = logging.getLogger("supervisor.core")


@dataclass
class RoutingDecision:
    agent_names: list[str]
    response: str
    scores: dict[str, float] = field(default_factory=dict)


class SupervisorAgent:
    def __init__(
        self,
        agents: list[BaseAgent],
        config: SupervisorConfig | None = None,
        session_store: SessionStore | None = None,
    ):
        self.config = config or SupervisorConfig.load()
        self.agents: dict[AgentType, BaseAgent] = {agent.agent_type: agent for agent in agents}
        self._fallback = self.agents.get(AgentType.CHAT)
        self.session_store = session_store
        # In-process fallback so conversation memory still works across
        # turns within the same run even when no SessionStore is wired up
        # (e.g. in unit tests, or a quick script) — without this, every
        # `route()` call would silently load a brand-new empty AgentState
        # and "what about tomorrow?" would never resolve to anything.
        self._memory_states: dict[str, AgentState] = {}
        self.metrics = SupervisorMetrics()

        if self.config.plugins_dir:
            for plugin in load_plugins(self.config.plugins_dir):
                self.agents[plugin.agent_type] = plugin

    # -- public API -------------------------------------------------------

    async def route(self, query: str, session_id: str = "default") -> RoutingDecision:
        start = time.perf_counter()
        state = await self._load_state(session_id)

        clauses = await self._split_clauses(query, state)

        if self.config.parallel and len(clauses) > 1:
            agent_names, responses, failed = await self._execute_parallel(clauses, state)
        else:
            agent_names, responses, failed = await self._execute_sequential(clauses, state)

        elapsed_ms = (time.perf_counter() - start) * 1000
        await self.metrics.record(agent_names, elapsed_ms, failed)

        scores = {}
        for name in set(agent_names):
            if name in AgentType._value2member_map_:
                scores[name] = await self.agents[AgentType(name)].can_handle(query, state)

        state.history.append({"query": query, "agent": " + ".join(agent_names), "response": " | ".join(responses)})
        # Keep every distinct agent used this turn, not just the last clause's
        # agent — a multi-intent turn like "weather in X and calculate Y"
        # would otherwise clobber "last_agent" with CalculatorAgent, so a
        # follow-up like "what about tomorrow?" would wrongly route back to
        # the calculator instead of the weather agent it actually refers to.
        state.context["last_agents"] = list(dict.fromkeys(agent_names))
        state.context["last_agent"] = agent_names[-1] if agent_names else None
        await self._save_state(state)

        logger.info("query=%r routed_to=%s time=%.2fms failed=%s", query, agent_names, elapsed_ms, failed)

        return RoutingDecision(
            agent_names=agent_names,
            response=ResponseAggregator.aggregate(agent_names, responses),
            scores=scores,
        )

    async def handle(self, query: str, session_id: str = "default") -> str:
        return (await self.route(query, session_id)).response

    async def route_stream(self, query: str, session_id: str = "default") -> AsyncIterator[str]:
        """Stream the response for a (typically single-clause) query,
        chunk by chunk, updating and persisting state once streaming
        completes. Multi-clause queries are streamed clause-by-clause in
        order (not interleaved), each prefixed with its agent's name."""
        state = await self._load_state(session_id)
        clauses = await self._split_clauses(query, state)
        agent_names: list[str] = []
        full_responses: list[str] = []
        any_failed = False
        start = time.perf_counter()

        for clause in clauses:
            agent, _ = await self._select_agent(clause, state)
            if len(clauses) > 1:
                yield f"\n**{agent.agent_type.value}**: "
            collected = []
            try:
                async for chunk in agent.stream(clause, state):
                    collected.append(chunk)
                    yield chunk
            except Exception as exc:
                any_failed = True
                logger.warning("agent=%s clause=%r stream raised %s", agent.agent_type.value, clause, exc)
                apology = self._fallback.apology(str(exc)) if self._fallback else "Sorry, something went wrong."
                collected = [apology]
                yield apology
            agent_names.append(agent.agent_type.value)
            full_responses.append("".join(collected))

        elapsed_ms = (time.perf_counter() - start) * 1000
        await self.metrics.record(agent_names, elapsed_ms, any_failed)
        state.history.append({
            "query": query,
            "agent": " + ".join(agent_names),
            "response": " | ".join(full_responses),
        })
        state.context["last_agent"] = agent_names[-1] if agent_names else None
        await self._save_state(state)

    def metrics_summary(self) -> dict:
        return self.metrics.summary()

    # -- state persistence -------------------------------------------------

    async def _load_state(self, session_id: str) -> AgentState:
        if self.session_store is not None:
            return await self.session_store.load(session_id)
        return self._memory_states.get(session_id) or AgentState(session_id=session_id)

    async def _save_state(self, state: AgentState) -> None:
        if self.session_store is not None:
            await self.session_store.save(state)
        else:
            self._memory_states[state.session_id] = state

    # -- internals ----------------------------------------------------------

    async def _execute_sequential(self, clauses: list[str], state: AgentState) -> tuple[list[str], list[str], bool]:
        agent_names, responses, any_failed = [], [], False
        for clause in clauses:
            name, response, failed = await self._run_with_retry(clause, state)
            agent_names.append(name)
            responses.append(response)
            any_failed = any_failed or failed
        return agent_names, responses, any_failed

    async def _execute_parallel(self, clauses: list[str], state: AgentState) -> tuple[list[str], list[str], bool]:
        local_states = [state.clone_for_clause() for _ in clauses]
        tasks = [self._run_with_retry(clause, local_state) for clause, local_state in zip(clauses, local_states)]
        results = await asyncio.gather(*tasks)

        agent_names, responses, any_failed = [], [], False
        for (name, response, failed), local_state in zip(results, local_states):
            agent_names.append(name)
            responses.append(response)
            any_failed = any_failed or failed
            state.merge_from(local_state)
        return agent_names, responses, any_failed

    async def _run_with_retry(self, clause: str, state: AgentState) -> tuple[str, str, bool]:
        agent, score = await self._select_agent(clause, state)
        last_error: Exception | None = None
        for attempt in range(1, self.config.max_retries + 1):
            try:
                response = await asyncio.wait_for(
                    agent.handle(clause, state), timeout=self.config.request_timeout_s
                )
                return agent.agent_type.value, response, False
            except Exception as exc:  # agent-level bug or timeout shouldn't crash the whole turn
                last_error = exc
                logger.warning(
                    "agent=%s clause=%r attempt=%d/%d raised %s",
                    agent.agent_type.value, clause, attempt, self.config.max_retries, exc,
                )
        if self._fallback is not None:
            reason = str(last_error) if last_error else "unknown error"
            return self._fallback.agent_type.value, self._fallback.apology(reason), True
        return agent.agent_type.value, "Sorry, something went wrong.", True

    async def _select_agent(self, query: str, state: AgentState) -> tuple[BaseAgent, float]:
        scores = await asyncio.gather(*(agent.can_handle(query, state) for agent in self.agents.values()))
        scored = list(zip(self.agents.values(), scores))
        best_agent, best_score = max(scored, key=lambda pair: pair[1])

        if best_score < self.config.min_confidence and len(query.split()) <= 5:
            # Memory-based fallback for short follow-ups ("what about
            # tomorrow?"). Consider every agent used in the *previous* turn
            # (not just the last clause's agent — see note in `route()`)
            # and re-score the follow-up against each candidate, picking
            # whichever one is the best fit rather than blindly reusing
            # whichever agent happened to run last.
            candidate_names = state.context.get("last_agents") or (
                [state.context["last_agent"]] if state.context.get("last_agent") else []
            )
            candidates = [
                self.agents[AgentType(name)]
                for name in candidate_names
                if name in AgentType._value2member_map_ and AgentType(name) in self.agents
            ]
            if candidates:
                candidate_scores = await asyncio.gather(*(c.can_handle(query, state) for c in candidates))
                best_candidate, candidate_score = max(zip(candidates, candidate_scores), key=lambda p: p[1])
                if candidate_score > 0:
                    logger.info(
                        "Low confidence (%.2f); reusing %s for follow-up (candidate score %.2f)",
                        best_score, best_candidate.agent_type.value, candidate_score,
                    )
                    return best_candidate, best_score
            if self._fallback is not None:
                fallback_score = await self._fallback.can_handle(query, state)
                return self._fallback, fallback_score

        return best_agent, best_score

    async def _split_clauses(self, query: str, state: AgentState) -> list[str]:
        parts = [p.strip() for p in re.split(r"\s*,\s*|\s+\band\b\s+|\s+\balso\b\s+", query) if p.strip()]
        if len(parts) < 2:
            return [query]
        for part in parts:
            _, score = await self._select_agent(part, state)
            if score < self.config.multi_threshold:
                return [query]
        return parts
