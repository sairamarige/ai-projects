"""Wires up the default agent set, sharing one TF-IDF corpus across agents
so IDF weights reflect the whole system's vocabulary, not just one agent's
private example list."""
from __future__ import annotations

from app.agents.calculator import CalculatorAgent
from app.agents.chat import GeneralChatAgent
from app.agents.python_agent import PythonAgent
from app.agents.weather import WeatherAgent
from app.config import SupervisorConfig
from app.persistence import SessionStore
from app.scoring import build_shared_corpus
from app.supervisor import SupervisorAgent


def build_default_agents() -> list:
    corpus = build_shared_corpus(
        WeatherAgent.example_phrases,
        CalculatorAgent.example_phrases,
        PythonAgent.example_phrases,
    )
    return [
        WeatherAgent(corpus),
        CalculatorAgent(corpus),
        PythonAgent(corpus),
        GeneralChatAgent(),
    ]


async def build_default_supervisor(config: SupervisorConfig | None = None) -> SupervisorAgent:
    config = config or SupervisorConfig.load()
    store = SessionStore(config.db_path)
    await store.connect()
    return SupervisorAgent(agents=build_default_agents(), config=config, session_store=store)
