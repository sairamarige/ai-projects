"""Dynamic plugin discovery — scan a directory for BaseAgent subclasses."""
from __future__ import annotations

import importlib.util
import inspect
import logging
from pathlib import Path

from app.agents.base import BaseAgent

logger = logging.getLogger("supervisor.plugins")


def load_plugins(directory: str | Path) -> list[BaseAgent]:
    """Scan `directory` for .py files, import them, and instantiate any
    BaseAgent subclasses found. Lets you add agents by dropping a file in
    the plugins folder instead of editing the Supervisor's construction."""
    directory = Path(directory)
    discovered: list[BaseAgent] = []
    if not directory.exists():
        return discovered

    for py_file in sorted(directory.glob("*.py")):
        if py_file.name.startswith("_"):
            continue
        module_name = f"supervisor_plugins.{py_file.stem}"
        spec = importlib.util.spec_from_file_location(module_name, py_file)
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:  # plugin authors' bugs shouldn't crash startup
            logger.warning("Failed to load plugin %s: %s", py_file.name, exc)
            continue

        for _, obj in inspect.getmembers(module, inspect.isclass):
            # Duck-type rather than a bare `issubclass` check: if this file
            # is ever imported under two different module identities (e.g.
            # a plugin doing `from app.agents.base import BaseAgent` while
            # the app itself was launched as a script rather than a
            # package), issubclass could compare two non-identical
            # BaseAgent class objects and silently return False.
            if obj.__module__ != module_name:
                continue
            if inspect.isabstract(obj):
                continue
            if not (hasattr(obj, "can_handle") and hasattr(obj, "handle") and hasattr(obj, "agent_type")):
                continue
            try:
                discovered.append(obj())
                logger.info("Loaded plugin agent: %s", obj.__name__)
            except Exception as exc:
                logger.warning("Failed to instantiate plugin agent %s: %s", obj.__name__, exc)
    return discovered
