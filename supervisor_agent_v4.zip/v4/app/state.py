"""Shared state threaded through every agent call, one instance per session."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class AgentState:
    """Per-session state.

    - `context` holds durable memory (e.g. last city, last agent used).
    - `history` is an append-only log of past turns.
    - `results` holds per-clause outputs *within* a single multi-intent turn.
    """

    session_id: str = "default"
    context: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, str]] = field(default_factory=list)
    results: dict[str, str] = field(default_factory=dict)

    def clone_for_clause(self) -> "AgentState":
        """Shallow copy used per-clause during parallel execution, so
        concurrent agents don't race on the same dict/list objects."""
        return AgentState(session_id=self.session_id, context=dict(self.context), history=list(self.history), results={})

    def merge_from(self, other: "AgentState") -> None:
        """Merge a clause-local state's context changes back into this
        shared state after parallel execution completes."""
        self.context.update(other.context)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentState":
        return cls(
            session_id=data.get("session_id", "default"),
            context=data.get("context", {}),
            history=data.get("history", []),
            results={},
        )
