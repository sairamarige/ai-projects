"""Query count, latency, per-agent usage, and failure-rate tracking."""
from __future__ import annotations

import asyncio
from collections import Counter
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SupervisorMetrics:
    total_queries: int = 0
    total_latency_ms: float = 0.0
    agent_usage: Counter = field(default_factory=Counter)
    failures: int = 0

    def __post_init__(self) -> None:
        # Guards metric updates across concurrently-handled requests in the
        # FastAPI service (multiple in-flight requests share one Supervisor).
        self._lock = asyncio.Lock()

    async def record(self, agent_names: list[str], latency_ms: float, failed: bool) -> None:
        async with self._lock:
            self.total_queries += 1
            self.total_latency_ms += latency_ms
            self.agent_usage.update(agent_names)
            if failed:
                self.failures += 1

    def summary(self) -> dict[str, Any]:
        avg_latency = self.total_latency_ms / self.total_queries if self.total_queries else 0.0
        failure_rate = self.failures / self.total_queries if self.total_queries else 0.0
        return {
            "total_queries": self.total_queries,
            "average_latency_ms": round(avg_latency, 3),
            "agent_usage": dict(self.agent_usage),
            "failure_rate": round(failure_rate, 3),
        }
