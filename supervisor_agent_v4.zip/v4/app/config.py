"""Configuration — loaded from config.json, overridable via env vars."""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger("supervisor.config")


@dataclass
class SupervisorConfig:
    min_confidence: float = 0.3
    multi_threshold: float = 0.5
    max_retries: int = 2
    parallel: bool = True
    plugins_dir: str = "app/plugins"
    db_path: str = "supervisor.db"
    request_timeout_s: float = 10.0
    stream_chunk_size: int = 24  # characters per streamed chunk

    @classmethod
    def load(cls, path: str | Path = "config.json") -> "SupervisorConfig":
        data: dict[str, Any] = {}
        path = Path(path)
        if path.exists():
            try:
                data = json.loads(path.read_text())
            except json.JSONDecodeError:
                logger.warning("config.json is invalid JSON; using defaults")

        cfg = cls(**{k: data.get(k, getattr(cls, k)) for k in cls.__dataclass_fields__}) if data else cls()

        env_map = {
            "SUPERVISOR_MIN_CONFIDENCE": ("min_confidence", float),
            "SUPERVISOR_MULTI_THRESHOLD": ("multi_threshold", float),
            "SUPERVISOR_MAX_RETRIES": ("max_retries", int),
            "SUPERVISOR_PARALLEL": ("parallel", lambda v: v.lower() in ("1", "true", "yes")),
            "SUPERVISOR_PLUGINS_DIR": ("plugins_dir", str),
            "SUPERVISOR_DB_PATH": ("db_path", str),
            "SUPERVISOR_REQUEST_TIMEOUT_S": ("request_timeout_s", float),
            "SUPERVISOR_STREAM_CHUNK_SIZE": ("stream_chunk_size", int),
        }
        for env_key, (attr, caster) in env_map.items():
            if env_key in os.environ:
                setattr(cfg, attr, caster(os.environ[env_key]))
        return cfg
