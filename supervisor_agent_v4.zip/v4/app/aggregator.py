"""Merges per-clause agent responses into one final answer."""
from __future__ import annotations


class ResponseAggregator:
    @staticmethod
    def aggregate(agent_names: list[str], responses: list[str]) -> str:
        if len(responses) == 1:
            return responses[0]
        lines = [f"**{name}**: {resp}" for name, resp in zip(agent_names, responses)]
        return "\n".join(lines)
