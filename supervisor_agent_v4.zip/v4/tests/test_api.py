from __future__ import annotations

import os

import httpx
import pytest
import pytest_asyncio

os.environ.setdefault("SUPERVISOR_DB_PATH", ":memory:")
os.environ.setdefault("SUPERVISOR_PLUGINS_DIR", "app/plugins")

from app.api import app  # noqa: E402  (env vars must be set before import)


@pytest_asyncio.fixture
async def client():
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        # Trigger FastAPI lifespan (startup/shutdown) manually via the transport's
        # LifespanManager equivalent: httpx's ASGITransport does not auto-run
        # lifespan events, so we drive them explicitly here.
        async with _lifespan(app):
            yield c


from contextlib import asynccontextmanager


@asynccontextmanager
async def _lifespan(app):
    async with app.router.lifespan_context(app):
        yield


async def test_health(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


async def test_chat_endpoint_routes_weather(client):
    resp = await client.post("/chat", json={"query": "weather in Hyderabad", "session_id": "t1"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["agent_names"] == ["WeatherAgent"]
    assert "Hyderabad" in body["response"]


async def test_chat_endpoint_validates_empty_query(client):
    resp = await client.post("/chat", json={"query": "", "session_id": "t1"})
    assert resp.status_code == 422


async def test_history_endpoint_reflects_prior_chat(client):
    await client.post("/chat", json={"query": "weather in Oslo", "session_id": "t2"})
    resp = await client.get("/sessions/t2/history")
    assert resp.status_code == 200
    body = resp.json()
    assert body["context"]["last_city"] == "Oslo"
    assert len(body["history"]) == 1


async def test_delete_session_clears_history(client):
    await client.post("/chat", json={"query": "weather in Cairo", "session_id": "t3"})
    resp = await client.delete("/sessions/t3")
    assert resp.status_code == 200
    resp2 = await client.get("/sessions/t3/history")
    assert resp2.json()["context"] == {}


async def test_metrics_endpoint_increments(client):
    before = (await client.get("/metrics")).json()["total_queries"]
    await client.post("/chat", json={"query": "hello", "session_id": "t4"})
    after = (await client.get("/metrics")).json()["total_queries"]
    assert after == before + 1


async def test_stream_endpoint_returns_sse_chunks(client):
    async with client.stream(
        "POST", "/chat/stream", json={"query": "translate hello to Spanish", "session_id": "t5"}
    ) as resp:
        assert resp.status_code == 200
        lines = [line async for line in resp.aiter_lines() if line.startswith("data: ")]
        assert lines[-1] == "data: [DONE]"
        payload = "".join(
            __import__("json").loads(line[len("data: "):])["chunk"] for line in lines[:-1]
        )
        assert "hola" in payload
