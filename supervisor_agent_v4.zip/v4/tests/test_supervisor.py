from __future__ import annotations

import asyncio
import time

import pytest

from app.agents.base import AgentType, BaseAgent
from app.agents.calculator import CalculatorAgent
from app.agents.chat import GeneralChatAgent
from app.agents.python_agent import PythonAgent
from app.agents.weather import WeatherAgent
from app.config import SupervisorConfig
from app.persistence import SessionStore
from app.scoring import build_shared_corpus
from app.state import AgentState
from app.supervisor import SupervisorAgent


def make_agents():
    corpus = build_shared_corpus(
        WeatherAgent.example_phrases, CalculatorAgent.example_phrases, PythonAgent.example_phrases
    )
    return [WeatherAgent(corpus), CalculatorAgent(corpus), PythonAgent(corpus), GeneralChatAgent()]


def make_config(**overrides) -> SupervisorConfig:
    cfg = SupervisorConfig(plugins_dir="", db_path=":memory:")
    for k, v in overrides.items():
        setattr(cfg, k, v)
    return cfg


# ---------------------------------------------------------------------------
# Routing basics
# ---------------------------------------------------------------------------

async def test_routes_weather_query():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    decision = await sup.route("What's the weather in Hyderabad?")
    assert decision.agent_names == ["WeatherAgent"]
    assert "Hyderabad" in decision.response


async def test_routes_calculator_query():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    decision = await sup.route("Calculate 12 * (3 + 4)")
    assert decision.agent_names == ["CalculatorAgent"]
    assert "84" in decision.response


async def test_greeting_routes_to_chat():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    decision = await sup.route("Hello there!")
    assert decision.agent_names == ["GeneralChatAgent"]


# ---------------------------------------------------------------------------
# Conversation memory
# ---------------------------------------------------------------------------

async def test_memory_followup_resolves_last_city():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    await sup.route("What's the weather in Tokyo?", session_id="s1")
    decision = await sup.route("What about tomorrow?", session_id="s1")
    assert decision.agent_names == ["WeatherAgent"]
    assert "Tokyo" in decision.response


async def test_multi_intent_followup_targets_correct_agent_not_last_clause():
    """Regression test: a prior bug made a follow-up after a multi-intent
    turn reuse whichever agent handled the *last* clause (CalculatorAgent),
    even when the follow-up clearly referred to the *other* clause
    (weather). The fix scores the follow-up against every agent used last
    turn and picks the best match."""
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    await sup.route("weather in Mumbai and calculate 7*8", session_id="s2")
    decision = await sup.route("what about tomorrow?", session_id="s2")
    assert decision.agent_names == ["WeatherAgent"]
    assert "Mumbai" in decision.response


async def test_sessions_are_isolated():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    await sup.route("What's the weather in London?", session_id="a")
    await sup.route("What's the weather in Delhi?", session_id="b")
    decision_a = await sup.route("What about tomorrow?", session_id="a")
    decision_b = await sup.route("What about tomorrow?", session_id="b")
    assert "London" in decision_a.response
    assert "Delhi" in decision_b.response


# ---------------------------------------------------------------------------
# Parallel execution
# ---------------------------------------------------------------------------

async def test_multi_intent_runs_both_agents():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    decision = await sup.route("What's the weather in Tokyo and calculate 45 + 90")
    assert set(decision.agent_names) == {"WeatherAgent", "CalculatorAgent"}
    assert "Tokyo" in decision.response and "135" in decision.response


class _SlowAgent(BaseAgent):
    agent_type = AgentType.CHAT
    example_phrases = ("slow thing",)

    async def can_handle(self, query, state=None):
        return 1.0 if "slow" in query.lower() else 0.0

    async def handle(self, query, state):
        await asyncio.sleep(0.2)
        return f"done: {query}"


async def test_parallel_execution_is_actually_concurrent():
    """Not just structurally parallel — verify two 0.2s clauses complete in
    ~0.2s total (concurrent), not ~0.4s (sequential)."""
    agents = [_SlowAgent(), GeneralChatAgent()]
    sup = SupervisorAgent(agents=agents, config=make_config(min_confidence=0.0, multi_threshold=0.0))

    start = time.perf_counter()
    decision = await sup.route("slow thing one and slow thing two")
    elapsed = time.perf_counter() - start

    assert len(decision.agent_names) == 2
    assert elapsed < 0.35, f"expected concurrent execution (~0.2s), took {elapsed:.2f}s"


# ---------------------------------------------------------------------------
# Retry & fallback
# ---------------------------------------------------------------------------

class _FlakyAgent(BaseAgent):
    agent_type = AgentType.WEATHER
    example_phrases = ()

    async def can_handle(self, query, state=None):
        return 1.0

    async def handle(self, query, state):
        raise RuntimeError("simulated network failure")


async def test_retry_exhausts_then_falls_back_to_chat():
    agents = [_FlakyAgent(), GeneralChatAgent()]
    sup = SupervisorAgent(agents=agents, config=make_config(max_retries=2))
    decision = await sup.route("anything")
    assert decision.agent_names == ["GeneralChatAgent"]
    assert "Sorry" in decision.response
    assert sup.metrics.failures == 1


async def test_timeout_triggers_fallback():
    class _Timeout(BaseAgent):
        agent_type = AgentType.WEATHER
        example_phrases = ()

        async def can_handle(self, query, state=None):
            return 1.0

        async def handle(self, query, state):
            await asyncio.sleep(5)
            return "too slow"

    agents = [_Timeout(), GeneralChatAgent()]
    sup = SupervisorAgent(agents=agents, config=make_config(max_retries=1, request_timeout_s=0.05))
    decision = await sup.route("anything")
    assert decision.agent_names == ["GeneralChatAgent"]


# ---------------------------------------------------------------------------
# Dynamic plugin discovery
# ---------------------------------------------------------------------------

async def test_plugin_translation_agent_loads_and_routes():
    cfg = make_config(plugins_dir="app/plugins")
    sup = SupervisorAgent(agents=make_agents(), config=cfg)
    assert AgentType.TRANSLATION in sup.agents
    decision = await sup.route("Translate hello to Spanish")
    assert decision.agent_names == ["TranslationAgent"]
    assert "hola" in decision.response


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

async def test_metrics_track_queries_and_usage():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    await sup.route("Hello!")
    await sup.route("Calculate 2 + 2")
    summary = sup.metrics_summary()
    assert summary["total_queries"] == 2
    assert summary["agent_usage"]["CalculatorAgent"] == 1
    assert summary["failure_rate"] == 0.0


async def test_concurrent_requests_do_not_corrupt_metrics():
    """Metrics are updated by many requests firing concurrently (as they
    would under real FastAPI traffic) — the async lock must prevent races."""
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    await asyncio.gather(*(sup.route(f"Calculate {i} + 1") for i in range(20)))
    assert sup.metrics_summary()["total_queries"] == 20


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------

async def test_route_stream_yields_chunks_and_persists_state():
    sup = SupervisorAgent(agents=make_agents(), config=make_config())
    chunks = [c async for c in sup.route_stream("What's the weather in Paris?", session_id="stream1")]
    assert "".join(chunks) == "Weather in Paris: 26°C, mild conditions (simulated default — city not in local data)"
    # follow-up should now resolve via persisted state
    decision = await sup.route("what about tomorrow?", session_id="stream1")
    assert "Paris" in decision.response


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

async def test_session_store_persists_across_supervisor_instances(tmp_path):
    db_path = tmp_path / "test.db"
    store1 = SessionStore(db_path)
    await store1.connect()
    sup1 = SupervisorAgent(agents=make_agents(), config=make_config(), session_store=store1)
    await sup1.route("What's the weather in Berlin?", session_id="p1")
    await store1.close()

    store2 = SessionStore(db_path)
    await store2.connect()
    sup2 = SupervisorAgent(agents=make_agents(), config=make_config(), session_store=store2)
    decision = await sup2.route("what about tomorrow?", session_id="p1")
    assert "Berlin" in decision.response
    await store2.close()


async def test_session_store_delete_clears_history():
    store = SessionStore(":memory:")
    await store.connect()
    state = AgentState(session_id="x", context={"last_city": "Rome"})
    await store.save(state)
    await store.delete("x")
    reloaded = await store.load("x")
    assert reloaded.context == {}
    await store.close()


# ---------------------------------------------------------------------------
# Semantic scoring (TF-IDF)
# ---------------------------------------------------------------------------

async def test_tfidf_scorer_distinguishes_domains_better_than_shared_stopwords():
    from app.scoring import TfidfScorer, build_shared_corpus

    corpus = build_shared_corpus(WeatherAgent.example_phrases, CalculatorAgent.example_phrases)
    weather_scorer = TfidfScorer(WeatherAgent.example_phrases, corpus)
    calc_scorer = TfidfScorer(CalculatorAgent.example_phrases, corpus)

    query = "what is the weather like"
    assert weather_scorer.score(query) > calc_scorer.score(query)
