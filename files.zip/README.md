# MCP Servers: Calculator & Employee Directory

Two small [Model Context Protocol](https://modelcontextprotocol.io) servers built with the
official Python SDK's `FastMCP` decorator API.

## Files

| File | Purpose |
|---|---|
| `calculator_server.py` | `add`, `subtract`, `multiply`, `divide` |
| `employee_server.py` | `get_employee`, `search_employee`, `employees_by_department` |
| `requirements.txt` | Pinned to `mcp<2.0` (see "Why pinned" below) |

## Setup

```bash
pip install -r requirements.txt
```

## Running / testing

Quick manual test with the MCP Inspector (opens a browser UI to call tools by hand):

```bash
mcp dev calculator_server.py
mcp dev employee_server.py
```

Or run a server directly (it will sit waiting for a client on stdio):

```bash
python calculator_server.py
```

### Connect from Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "calculator": {
      "command": "python3",
      "args": ["/absolute/path/to/calculator_server.py"]
    },
    "employees": {
      "command": "python3",
      "args": ["/absolute/path/to/employee_server.py"]
    }
  }
}
```

Restart Claude Desktop and the tools appear in its tool picker.

---

## The architecture, mapped to this code

```
User
  |
  v
AI Application        <-- e.g. Claude Desktop, or your own chat app
  |
  v
MCP Client            <-- built into the AI app; speaks MCP (JSON-RPC 2.0)
  |                        over stdio/SSE/streamable-HTTP
  v
Calculator MCP Server  <-- calculator_server.py: FastMCP("Calculator")
  |                        registers add/subtract/multiply/divide as tools
  v
Python Functions       <-- the plain functions decorated with @mcp.tool()
  |
  v
Result                 <-- e.g. 42 -- flows back up through the server,
                             MCP client, and AI app to the user
```

What each layer actually does:

1. **User** types something like "what's 7 times 6?" in a chat UI.
2. **AI application** (the LLM-hosting app) decides a tool call is needed and
   asks its embedded **MCP client** to call the `multiply` tool.
3. The **MCP client** sends a `tools/call` JSON-RPC request over the
   transport (stdio when running locally, as tested above; SSE/streamable-HTTP
   for a networked server).
4. The **MCP server** (`calculator_server.py`) receives the request, validates
   arguments against the tool's schema (auto-generated from the Python type
   hints), and dispatches to the matching **Python function**.
5. The function computes a **result** and returns it; the server wraps it in
   an MCP `CallToolResult` and sends it back down the same chain to the user.

This was verified end-to-end in this build: a real `ClientSession` over
`stdio_client` connected to `calculator_server.py`, listed its tools
(`['add', 'subtract', 'multiply', 'divide']`), and called `multiply(7, 6)`,
getting `42.0` back through the full protocol stack — not just a direct
Python function call.

The **Employee MCP Server** follows the identical shape, just with a
different "Python Functions" layer: instead of arithmetic, `get_employee`,
`search_employee`, and `employees_by_department` query an in-memory list of
employee dicts (`EMPLOYEES`). In production you'd swap that in-memory list
for a real call to a database or HR system inside each tool function — the
MCP-facing contract (tool name, arguments, return shape) wouldn't need to
change at all. That's the point of the MCP layer: it decouples the AI
application from *how* a capability is implemented.

## Tool reference

### Calculator

| Tool | Args | Returns |
|---|---|---|
| `add` | `a: float, b: float` | `a + b` |
| `subtract` | `a: float, b: float` | `a - b` |
| `multiply` | `a: float, b: float` | `a * b` |
| `divide` | `a: float, b: float` | `a / b` (raises on `b == 0`) |

### Employee Directory

| Tool | Args | Returns |
|---|---|---|
| `get_employee` | `employee_id: int` | Single employee dict (raises if not found) |
| `search_employee` | `query: str` | List of employees matching name/email/role (substring, case-insensitive) |
| `employees_by_department` | `department: str, role: Optional[str]` | List of employees in that department, optionally filtered by role keyword |

## Why pinned to `mcp<2.0`

The official SDK shipped a `2.0.0` beta that renames `FastMCP` to `MCPServer`
(moved to `mcp.server.mcpserver`) as part of support for the upcoming
2026-07-28 protocol revision. It's still in beta and client-side support is
still rolling out, so this build pins to the stable `1.x` line
(`mcp==1.29.0` at time of writing) for maximum compatibility with current
MCP clients like Claude Desktop. If you want the new stateless-protocol
API instead, see the SDK's migration guide for the `MCPServer` equivalent —
the decorator-based tool definitions (`@mcp.tool()`) carry over almost
unchanged.
